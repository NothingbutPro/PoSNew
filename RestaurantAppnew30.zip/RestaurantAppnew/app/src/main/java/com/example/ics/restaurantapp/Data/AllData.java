package com.example.ics.restaurantapp.Data;

import com.example.ics.restaurantapp.ModelDB.DineAreaOutput;
import com.example.ics.restaurantapp.ModelDB.FloorTableOutput;

import java.util.List;

/**
 * Created by ICS on 25/05/2018.
 */

public class AllData {
    public static List<DineAreaOutput> dineAreaOutput;
    public static List<FloorTableOutput> floorTableOutput;
}
